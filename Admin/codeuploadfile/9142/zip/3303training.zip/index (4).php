<?php


session_start();
// session_start();

if(!isset($_SESSION['tyu']))
{?>
  <script type='text/javascript'>
     
  
    window.location= "../../login_Vendor/Vendor_LogIn.php";
   
    </script> <?php
}

$email=$_SESSION['tyu'];

include ("../connection_login.php");

$q=mysqli_query($con,"SELECT uniq_name FROM properties WHERE email='$email' and media_status='media_submit' ORDER BY id DESC LIMIT 1");

// $q=mysqli_query($con,"SELECT uniq_name FROM properties WHERE email='$email'  ORDER BY id DESC LIMIT 1");
$r=mysqli_fetch_array($q);
$GLOBALS['uniqe']=$r['uniq_name'];




if(!isset($_SESSION['unst']))
{?>
  <script type='text/javascript'>
     
  
    window.location= "https://goworks.in/vendor/dashboard-my-properties.php";
   
    </script> <?php
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<form action="" method="post">
    





<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

  #p3 {background-color:rgb(0,0,255);}
* {
  box-sizing: border-box;
}

.columns {
  float: left;
  width: 50%;
  padding: 8px;
}

.price {
  list-style-type: none;
  border: 1px solid #eee;
  margin: 0;
  padding: 0;
  -webkit-transition: 0.3s;
  transition: 0.3s;
}

.price:hover {
  box-shadow: 0 8px 12px 0 rgba(0,0,0,0.2)
}

.price .header {
  background-color: #111;
  color: white;
  font-size: 25px;
}

.price li {
  border-bottom: 1px solid #eee;
  padding: 20px;
  text-align: center;
}

.price .grey {
  background-color: #eee;
  font-size: 20px;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  font-size: 18px;
}

@media only screen and (max-width: 600px) {
  .columns {
    width: 100%;
  }
}
</style>
</head>
<body>

<h2 style="text-align:center">Featuring  Pricing Option</h2>
<p style="text-align:center">Get Your Properties in Main Featured Section</p>

<div class="columns">
  <ul class="price">
    <li class="header">Premium</li>
    <li class="grey"> 999 / month</li>
    <li>Got Your Property in front</li>
    <!--<li>10 Emails</li>-->
    <!--<li>10 Domains</li>-->
    <li><div class="form-check">
  <input class="form-check-input" type="radio" name="price" onclick="val(this.value)" value="999" required>
  <label class="form-check-label" for="exampleRadios1">

 <button type="button" class="button"   name="btn" id="btn" onclick="pay_now()">Pay now</button>
  </label>
 
</div>
</li>
    
  </ul>
</div>

<!--<div class="columns">-->
<!--  <ul class="price">-->
<!--    <li class="header" style="background-color:#4CAF50">Pro</li>-->
<!--    <li class="grey">1999 / 3month</li>-->
<!--    <li>3 Month</li>-->
<!--    <li>25 Emails</li>-->
<!--    <li>25 Domains</li>-->
<!--    <li>-->
<!--    <div class="form-check">-->
<!--  <input class="form-check-input" type="radio" name="price" onclick="val(this.value)" value="1999" required>-->
<!--  <label class="form-check-label" for="exampleRadios2">-->


<!-- <button type="button" class="button" name="btn" id="btn" onclick="pay_now()">Pay now</button>-->
<!--  </label>-->
 
<!--</div>-->

<!--</li>-->
    
<!--  </ul>-->
<!--</div>-->

<!--<div class="columns">-->
<!--  <ul class="price">-->
<!--    <li class="header">Premium</li>-->
<!--    <li class="grey"> 4999 / year</li>-->
    
<!--    <li>50 Emails</li>-->
<!--    <li>50 Domains</li>-->
<!--    <li>5GB Bandwidth</li>-->
<!--    <li ><div class="form-check">-->
<!--  <input class="form-check-input" type="radio" onclick="val(this.value)" name="price" value="4999" required>-->
<!--  <label class="form-check-label" for="exampleRadios3"  class="button">-->
<!-- <button  type="button" name="btn" id="btn" class="button" onclick="pay_now()">Pay now</button>-->
 

<!--  </label>-->
<!--</div></li>-->
<!--  </ul>-->
<!--</div>-->
<div class="columns">
  <ul class="price">
    <li class="header" style="background-color:#17a2b8">Basic</li>
    <li class="grey"> 0.00 Charges</li>
    <li > Unpaid Totaly Free</li>
    
<li ><div class="form-check">
  <input class="form-check-input" type="radio" onclick="val(this.value)" name="price" value="unpaid" required>
  <label class="form-check-label" for="exampleRadios3"  class="button">
 <button  type="button" name="btn" id="btn" class="button" onclick="pay_now()">Free</button>
 

  </label>
</div></li>    
  </ul>
</div>
</body>
</html>
    
</form>


<script>
var value=0;
function val(id){
  value=id;
  console.log(value);
}
var email="<?php echo $email;?>";
var unipro="<?php echo $uniqe;?>";
function randomstring(){
  return "id_"+Math.random().toString(36).slice(2)+Math.random().toString(36).slice(2);
  
}

function pay_now(){




var orderid=randomstring();
var uniqueid=randomstring();
if(value == 0){
    swal("Caution", "Please Select mode of option");
// alert("Please Select Option");
}else{

if(value == "unpaid"){
  jQuery.ajax({
type:'post',
url:'paymentdata.php',
data:{
  "amount":value,
  "email":email,
  "orderid":orderid,
  "uniqueid":uniqueid,
  "unipro":unipro

},
success:function(result){

if(result == 'done'){
  swal("Caution", "Please Select mode of option");
  window.location='https://goworks.in/vendor/dashboard-my-properties.php';
}
  
}

      });

}else{



  jQuery.ajax({
type:'post',
url:'paymentdata.php',
data:{
  "amount":value,
  "email":email,
  "orderid":orderid,
  "uniqueid":uniqueid,
  "unipro":unipro

},
success:function(result){
console.log(result);
  
}

      });
  
  var options = {
    "key": "<?php echo $keyId ?>", 
    "amount": value*100, 
    "currency": "INR",
    "name": "Go Works",
    "description": "Leading the new Era",
    "image": "https://goworks.in/assets/img/logo.png", 
    "handler": function (response){
      
      jQuery.ajax({
type:'post',
url:'pay.php',
data:{
  "paymentid":response.razorpay_payment_id,
  "amount":value,
  "email":email,
  "orderid":orderid,
  "uniqueid":uniqueid,
  "unipro":unipro

},
success:function(result){

  if(result == "done"){
    swal({
  title: "Payment Done Succesfully!",
  text: "Check Your Mail For Recipt!",
  icon: "success",
  button: "Thank You!",
});
    
     window.location='https://goworks.in/vendor/dashboard-my-properties.php';

  }
}

      });
       
    }
};
var rzp1 = new Razorpay(options);
    rzp1.open();

} 
}
}
</script>
</body>
</html>




